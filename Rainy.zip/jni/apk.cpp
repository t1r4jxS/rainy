#include <stdio.h>
#include <MemoryTools.h>
#include <jni.h>
int main(int argc,char **argv)
{
	
	puts("完成");

}
